<?php
require_once 'includes/config.php';
requireLogin();
$user = getCurrentUser();


function formatMoney($amount) {
    if ($amount >= 1000000000000) return round($amount / 1000000000000, 1) . 'T';
    if ($amount >= 1000000000) return round($amount / 1000000000, 1) . 'B';
    if ($amount >= 1000000) return round($amount / 1000000, 1) . 'M';
    if ($amount >= 1000) return round($amount / 1000, 1) . 'K';
    return $amount;
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stasis - Home</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="nav">
        <div class="nav-left">
            <img src="assets/images/logo2.png" alt="STASIS" class="logo">
            <div class="nav-links">
                <a href="/home.php">Home</a> 
                <a href="/games.php">Games</a>
                <a href="/catalog/catalog.php">Catalog</a>
                <a href="/create.php">Create</a>
            </div>
        </div>
        <div class="nav-right">
            <span style="color:#fcd94c; margin-right: 15px;">
                <i class="fas fa-coins"></i> 
                <?php 
                echo formatMoney($user['currency']); 
                ?>
            </span>
            <span>Welcome, <?php echo htmlspecialchars($user['username']); ?></span>
            <a href="logout.php">Logout</a>
        </div>
    </div>

    <div class="container">
        <div class="profile-box">
            <div class="top-row">
                <div class="avatar-circle">
                    <img src="<?php echo getAvatar($user['id']); ?>" 
                         style="width:100%; height:100%; border-radius:50%; object-fit:cover;"
                         onerror="this.onerror=null; this.src='data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22150%22%20height%3D%22150%22%20viewBox%3D%220%200%20150%20150%22%3E%3Crect%20width%3D%22150%22%20height%3D%22150%22%20fill%3D%22%23333%22%2F%3E%3Ctext%20x%3D%2275%22%20y%3D%2290%22%20font-size%3D%2260%22%20text-anchor%3D%22middle%22%20fill%3D%22%23888%22%3E%3F%3C%2Ftext%3E%3C%2Fsvg%3E';">
                </div>
                <div class="username"><?php echo htmlspecialchars($user['username']); ?></div>
            </div>
            <div class="bottom-row">
                <div class="friends-box">
                    <div class="box-title">FRIENDS</div>
                    <div class="box-content">u have no friends :(</div>
                </div>
            </div>
        </div>
    </div>

    <div class="footer">
        © 2026 Stasis
    </div>
</body>
</html>