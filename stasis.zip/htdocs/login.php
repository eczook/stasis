<?php
require_once 'includes/config.php';


if (isLoggedIn()) {
    header('Location: home.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        $error = 'Please fill in all fields';
    } else {

        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $username]);
        $user = $stmt->fetch();
        
        if ($user && password_verify($password, $user['password'])) {
         
            $_SESSION['user_id'] = $user['id'];
            header('Location: home.php');
            exit;
        } else {
            $error = 'Invalid username or password';
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stasis - Login</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="nav">
        <div class="nav-left">
            <img src="assets/images/logo2.png" alt="STASIS" class="logo">
            <div class="nav-links">
                  <a href="/home.php">Home</a> 
                <a href="/games.php">Games</a>
                <a href="/catalog/catalog.php">Catalog</a>
                <a href="/create.php">Create</a>
            </div>
        </div>
        <div class="nav-right">
            <a href="https://discord.gg/d2sHx4wmcn">Discord</a>
        </div>
    </div>

    <div class="container">
        <div class="form-container">
            <img src="assets/images/logo2.png" alt="STASIS" class="form-logo">
            <div class="tagline">Sign in to Stasis</div>
            
            <?php if ($error): ?>
                <div class="error-msg"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="input-group">
                    <input type="text" name="username" placeholder="Username or Email" required value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>">
                </div>
                <div class="input-group">
                    <input type="password" name="password" placeholder="Password" required>
                </div>
                
                <button type="submit" class="form-btn">LOGIN</button>
            </form>
            
            <div class="form-footer">
                <a href="register.php">Don't have an account? Sign up</a>
            </div>
        </div>
    </div>

    <div class="footer">
        © 2026 Stasis
    </div>
</body>
</html>