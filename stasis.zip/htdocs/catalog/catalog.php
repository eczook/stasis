<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once '../includes/config.php';

$search = isset($_GET['search']) ? $_GET['search'] : '';

if (!empty($search)) {
    $stmt = $pdo->prepare("SELECT * FROM catalog_items WHERE name LIKE ? OR description LIKE ? ORDER BY id DESC");
    $stmt->execute(["%$search%", "%$search%"]);
    $items = $stmt->fetchAll();
} else {
    $items = $pdo->query("SELECT * FROM catalog_items ORDER BY id DESC")->fetchAll();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stasis - Catalog</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="nav">
        <div class="nav-left">
            <img src="../assets/images/logo2.png" alt="STASIS" class="logo">
            <div class="nav-links">
                <a href="/home.php">Home</a> 
                <a href="/games.php">Games</a>
                <a href="/catalog/catalog.php">Catalog</a>
                <a href="/create.php">Create</a>
            </div>
        </div>
        <div class="nav-right">
            <?php if (isLoggedIn()): ?>
                <?php $user = getCurrentUser(); ?>
                <span style="color:#fcd94c; margin-right: 15px;"><i class="fas fa-coins"></i> <?php echo $user['currency']; ?></span>
                <span>Welcome, <?php echo htmlspecialchars($user['username']); ?></span>
                <a href="/logout.php">Logout</a>
            <?php else: ?>
                <a href="/login.php">Sign In</a>
                <a href="/register.php">Sign Up</a>
            <?php endif; ?>
        </div>
    </div>

    <div class="container">
        <h1 style="color: #888; margin-bottom: 30px;">Catalog</h1>
        
        <form method="GET" style="margin-bottom: 20px; display: flex; gap: 10px; max-width: 500px;">
            <input type="text" name="search" placeholder="Search items..." value="<?php echo htmlspecialchars($search); ?>" style="flex: 1; padding: 10px; background: #1a1a1a; border: 1px solid #333; color: #fff;">
            <button type="submit" style="padding: 10px 20px; background: #1a1a1a; border: 1px solid #333; color: #fff;">Search</button>
        </form>
        
        <div style="display: flex; gap: 10px; margin-bottom: 30px;">
            <a href="?type=all" style="padding: 5px 15px; background: #1a1a1a; border: 1px solid #333; color: #ccc; text-decoration: none;">All</a>
             <a href="?type=hats" style="padding: 5px 15px; background: #1a1a1a; border: 1px solid #333; color: #ccc; text-decoration: none;">Hats</a>
        </div>
        
        
        <div class="catalog-grid">
            <?php foreach ($items as $item): ?>
                <a href="item.php?id=<?php echo $item['id']; ?>" style="text-decoration: none;">
                    <div class="catalog-item">
                        <div class="item-image">
                            <img src="<?php echo getItemRender($item['id']); ?>" style="width:100%; height:100%; object-fit:contain;" onerror="this.src='data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%200%20100%20100%22%3E%3Crect%20width%3D%22100%22%20height%3D%22100%22%20fill%3D%22%23222%22%2F%3E%3Ctext%20x%3D%2250%22%20y%3D%2265%22%20font-size%3D%2220%22%20text-anchor%3D%22middle%22%20fill%3D%22%23666%22%3E%3F%3C%2Ftext%3E%3C%2Fsvg%3E';">
                        </div>
                        <div class="item-name"><?php echo htmlspecialchars($item['name']); ?></div>
                        <div style="color:#fcd94c; font-size:14px; margin-top:5px;">
                            <i class="fas fa-coins"></i> <?php echo $item['price']; ?>
                        </div>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="footer">
        © 2026 Stasis
    </div>
</body>
</html>