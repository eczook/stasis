
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once '../includes/config.php';
requireLogin();

    require_once '../includes/config.php';
requireLogin();

$item_id = isset($_POST['item_id']) ? (int)$_POST['item_id'] : 0;


$stmt = $pdo->prepare("SELECT * FROM catalog_items WHERE id = ?");
$stmt->execute([$item_id]);
$item = $stmt->fetch();

if (!$item) {
    header('Location: catalog.php');
    exit;
}


$stmt = $pdo->prepare("SELECT * FROM inventory WHERE user_id = ? AND item_id = ?");
$stmt->execute([$_SESSION['user_id'], $item_id]);
if ($stmt->fetch()) {
    header('Location: item.php?id=' . $item_id . '&error=already_owned');
    exit;
}


$stmt = $pdo->prepare("SELECT currency FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();


if ($user['currency'] < $item['price']) {
    header('Location: item.php?id=' . $item_id . '&error=insufficient_funds');
    exit;
}


$pdo->beginTransaction();

try {
 
    $stmt = $pdo->prepare("UPDATE users SET currency = currency - ? WHERE id = ?");
    $stmt->execute([$item['price'], $_SESSION['user_id']]);
    
 
    $stmt = $pdo->prepare("INSERT INTO inventory (user_id, item_id) VALUES (?, ?)");
    $stmt->execute([$_SESSION['user_id'], $item_id]);
    
    $pdo->commit();
    
    header('Location: item.php?id=' . $item_id . '&success=purchased');
} catch (Exception $e) {
    $pdo->rollBack();
    header('Location: item.php?id=' . $item_id . '&error=purchase_failed');
}
exit;
?>