<?php
require_once '../includes/config.php';

$id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("SELECT * FROM catalog_items WHERE id = ?");
$stmt->execute([$id]);
$item = $stmt->fetch();

if (!$item) {
    header('Location: catalog.php');
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title><?php echo $item['name']; ?> - Stasis</title>
    <link rel="stylesheet" href="../assets/css/style.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #888;
            text-decoration: none;
        }
        
        .item-page {
            background: #1a1a1a;
            border: 1px solid #333;
            padding: 20px;
            max-width: 800px;
        }
        
        .item-content {
            display: flex;
            gap: 20px;
        }
        
        .item-image {
            width: 200px;
            height: 200px;
            background: #222;
            border: 1px solid #333;
            flex-shrink: 0;
        }
        
        .item-right {
            flex: 1;
        }
        
        .item-title {
            font-size: 24px;
            color: #fff;
            margin-bottom: 15px;
        }
        
        .item-description {
            color: #aaa;
            font-size: 14px;
            line-height: 1.6;
            margin-bottom: 20px;
            padding: 15px;
            background: #0f1217;
            border: 1px solid #222;
            min-height: 120px;
        }
        
        .price-row {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 20px;
        }
        
        .price-label {
            color: #888;
        }
        
        .price-value {
            color: #00aaff;
            font-size: 20px;
            font-weight: bold;
        }
        
  .buy-btn {
    background: linear-gradient(180deg, #1a1a1a 0%, #0f0f0f 100%);
    border: 1px solid #333;
    color: #cdcdcd;
    font-size: 16px;
    font-weight: bold;
    padding: 12px 30px;
    cursor: pointer;
    transition: 0.2s;
}

.buy-btn:hover {
    background: linear-gradient(180deg, #222 0%, #111 100%);
    border-color: #cdcdcd;
}
    </style>
</head>
<body>
  <div class="nav">
        <div class="nav-left">
            <img src="../assets/images/logo2.png" alt="STASIS" class="logo">
            <div class="nav-links">
               <a href="/home.php">Home</a> 
                <a href="/games.php">Games</a>
                <a href="/catalog/catalog.php">Catalog</a>
                <a href="/create.php">Create</a>
            </div>
        </div>
        <div class="nav-right">
            <?php if (isLoggedIn()): ?>
                <?php $user = getCurrentUser(); ?>
                <span style="color: #fcd94c; margin-right: 15px;"><i class="fas fa-coins"></i> <?php echo $user['currency']; ?></span>
                <span>Welcome, <?php echo htmlspecialchars($user['username']); ?></span>
                <a href="/logout.php">Logout</a>
            <?php else: ?>
                <a href="/login.php">Sign In</a>
                <a href="/register.php">Sign Up</a>
            <?php endif; ?>
        </div>
    </div>

    <div class="container">
        <a href="catalog.php" class="back-link">← Back to Catalog</a>
        <?php if (isset($_GET['error'])): ?>
   
        <div style="background: #2d1a1a; border: 1px solid #4f2b2b; color: #ff8a8a; padding: 10px; margin-bottom: 20px;">
        <?php 
        if ($_GET['error'] == 'insufficient_funds') echo 'Not enough currency!';
        elseif ($_GET['error'] == 'already_owned') echo 'You already own this item!';
        else echo 'Purchase failed. Try again.';
        ?>
    </div>
<?php endif; ?>

<?php if (isset($_GET['success'])): ?>
    <div style="background: #1a2d1a; border: 1px solid #2b4f2b; color: #8aff8a; padding: 10px; margin-bottom: 20px;">
        Purchase successful!
    </div>
<?php endif; ?>
        
        <div class="item-page">
            <div class="item-content">
              <div class="item-image">
    <img src="<?php echo getItemRender($item['id']); ?>" style="width:100%; height:100%; object-fit:contain;">
</div>
                <div class="item-right">
                    <div class="item-title"><?php echo htmlspecialchars($item['name']); ?></div>
                    <div class="item-description">
                        <?php echo nl2br(htmlspecialchars($item['description'] ?: 'No description provided.')); ?>
                    </div>
                    <div class="price-row">
                        <span class="price-label">Price:</span>
                         <span><i class="fas fa-coins"></i> <?php echo number_format($item['price']); ?></span>
                    </div>
                   <form method="POST" action="buy.php">
    <input type="hidden" name="item_id" value="<?php echo $item['id']; ?>">
    <button type="submit" class="buy-btn">Buy Now</button>
</form>
                </div>
            </div>
        </div>
    </div>

    <div class="footer">© 2026 Stasis</div>
</body>
</html>