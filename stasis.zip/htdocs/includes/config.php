<?php
session_start();

define('DB_HOST', 'sql301.ezyro.com');
define('DB_NAME', 'ezyro_41230130_stasis');
define('DB_USER', 'ezyro_41230130');
define('DB_PASS', '981343f0c0');

define('SITE_URL', 'https://stasis.gw.to');
define('SITE_NAME', 'Stasis');

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

function formatCurrency($amount) {

    if ($amount >= 1000000000000) {

        return round($amount / 1000000000000, 1) . 'T';

    } elseif ($amount >= 1000000000) {

        return round($amount / 1000000000, 1) . 'B';

    } elseif ($amount >= 1000000) {

        return round($amount / 1000000, 1) . 'M';

    } elseif ($amount >= 1000) {

        return round($amount / 1000, 1) . 'K';

    } else {

        return (string)$amount;

    }

}

function getAvatar($userId) {
    return "https://t3.epik17.xyz/" . $userId . "&width=150&height=150&format=png";
}

function getItemRender($itemId) {
    return "https://t3.epik17.xyz/" . $itemId . "&width=150&height=150&format=png";
}

require_once __DIR__ . '/auth.php';
?>