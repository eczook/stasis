<div class="footer">
    © 2026 Stasis
</div>