<?php
?>
<div class="nav">
    <div class="nav-left">
        <img src="../assets/images/logo2.png" alt="STASIS" class="logo">
        <div class="nav-links">
            <a href="/home.php">Home</a> 
            <a href="/games.php">Games</a>
            <a href="/catalog/catalog.php">Catalog</a>
            <a href="/create.php">Create</a>
        </div>
    </div>
    <div class="nav-right">
        <?php if (isLoggedIn()): ?>
            <?php $user = getCurrentUser(); ?>
          <span style="color:#fcd94c; margin-right: 15px;"><i class="fas fa-coins"></i> <?php echo $user['currency']; ?></span>
        <span>Welcome, <?php echo htmlspecialchars($user['username']); ?></span>
           
       <a href="/logout.php">Logout</a>
        <?php else: ?>
            <a href="/login.php">Sign In</a>
            <a href="/register.php">Sign Up</a>
        <?php endif; ?>
    </div>
</div>