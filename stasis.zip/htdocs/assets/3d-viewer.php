<!DOCTYPE html>
<html>
<head>
    <title>3D Viewer</title>
    <style>
        body { margin: 0; overflow: hidden; background: #0a0c10; }
        #info {
            position: absolute;
            top: 20px;
            left: 20px;
            color: white;
            z-index: 100;
        }
    </style>
</head>
<body>
    <div id="info">Stasis 3D Viewer</div>
    
    <script type="module">
        import * as THREE from 'three';
        import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
        import { OBJLoader } from 'three/addons/loaders/OBJLoader.js';
        
        // Setup scene
        const scene = new THREE.Scene();
        scene.background = new THREE.Color(0x0a0c10);
        
        // Camera
        const camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 1000);
        camera.position.set(2, 1.5, 3);
        
        // Renderer
        const renderer = new THREE.WebGLRenderer({ antialias: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.shadowMap.enabled = true;
        document.body.appendChild(renderer.domElement);
        
        // Controls
        const controls = new OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true;
        controls.autoRotate = true;
        controls.autoRotateSpeed = 2.0;
        
        // Lighting
        const ambientLight = new THREE.AmbientLight(0x404060);
        scene.add(ambientLight);
        
        const dirLight = new THREE.DirectionalLight(0xffffff, 1);
        dirLight.position.set(2, 5, 3);
        scene.add(dirLight);
        
        // Grid floor
        const gridHelper = new THREE.GridHelper(5, 20, 0x336699, 0x224466);
        scene.add(gridHelper);
        
        // Load your model
        const loader = new OBJLoader();
        
        // Get model from URL parameter or use default
        const urlParams = new URLSearchParams(window.location.search);
        const modelFile = urlParams.get('model') || 'avatar.obj';
        
        loader.load(
            '/assets/models/' + modelFile,
            function(object) {
                object.traverse(function(child) {
                    if (child.isMesh) {
                        child.material.color.setHex(0x3366cc);
                        child.castShadow = true;
                        child.receiveShadow = true;
                    }
                });
                scene.add(object);
            },
            function(xhr) {
                console.log((xhr.loaded / xhr.total * 100) + '% loaded');
            },
            function(error) {
                console.error('Error loading model:', error);
            }
        );
        
        // Animation loop
        function animate() {
            requestAnimationFrame(animate);
            controls.update();
            renderer.render(scene, camera);
        }
        animate();
        
        // Handle window resize
        window.addEventListener('resize', onWindowResize, false);
        function onWindowResize() {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
        }
    </script>
</body>
</html>