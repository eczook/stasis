<?php
require_once 'includes/config.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$stmt = $pdo->prepare("SELECT * FROM games WHERE id = ?");
$stmt->execute([$id]);
$game = $stmt->fetch();

if (!$game) {
    header('Location: games.php');
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $game['name']; ?> - Stasis</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .game-page {
            max-width: 900px;
        }
        
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #888;
            text-decoration: none;
        }
        
        .game-header {
            background: #1a1a1a;
            border: 1px solid #333;
            padding: 30px;
            margin-bottom: 20px;
        }
        
        .game-title {
            font-size: 32px;
            color: #fff;
            margin-bottom: 10px;
        }
        
        .game-creator {
            color: #888;
            margin-bottom: 20px;
            font-size: 14px;
        }
        
        .game-thumbnail-large {
            width: 100%;
            height: 300px;
            background: #222;
            border: 1px solid #333;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 80px;
            color: #444;
        }
        
        .game-description {
            color: #aaa;
            line-height: 1.6;
            margin-bottom: 30px;
            padding: 20px;
            background: #0f1217;
            border: 1px solid #222;
        }
        
        .game-stats-bar {
            display: flex;
            gap: 40px;
            margin-bottom: 30px;
            padding: 15px;
            background: #0f1217;
            border: 1px solid #222;
        }
        
        .stat-item {
            text-align: center;
        }
        
        .stat-value {
            color: #fcd94c;
            font-size: 24px;
            font-weight: bold;
        }
        
        .stat-label {
            color: #888;
            font-size: 12px;
        }
        
        .play-btn {
            padding: 15px 40px;
            background: #fcd94c;
            border: none;
            color: #000;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            width: 100%;
        }
        
        .play-btn:hover {
            background: #e5c43b;
        }
    </style>
</head>
<body>
    <?php include 'includes/nav.php'; ?>

    <div class="container">
        <a href="games.php" class="back-link"><i class="fas fa-arrow-left"></i> Back to Games</a>
        
        <div class="game-page">
            <div class="game-header">
                <div class="game-thumbnail-large">
                    <?php if ($game['thumbnail_url']): ?>
                        <img src="<?php echo $game['thumbnail_url']; ?>" style="width:100%; height:100%; object-fit:cover;">
                    <?php else: ?>
                        <i class="fas fa-gamepad"></i>
                    <?php endif; ?>
                </div>
                
                <div class="game-title"><?php echo htmlspecialchars($game['name']); ?></div>
                <div class="game-creator">Created by <?php echo htmlspecialchars($game['creator_name']); ?></div>
                
                <div class="game-stats-bar">
                    <div class="stat-item">
                        <div class="stat-value"><?php echo number_format($game['plays']); ?></div>
                        <div class="stat-label">Plays</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value"><?php echo number_format($game['favorites']); ?></div>
                        <div class="stat-label">Favorites</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value"><?php echo $game['rating']; ?>/5</div>
                        <div class="stat-label">Rating</div>
                    </div>
                </div>
                
                <div class="game-description">
                    <?php echo nl2br(htmlspecialchars($game['description'] ?: 'No description provided.')); ?>
                </div>
                
                <button class="play-btn" onclick="alert('client coming soon')"><i class="fas fa-play"></i> Play</button>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>
</body>
</html>