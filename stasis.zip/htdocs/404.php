<?php
http_response_code(404);
require_once 'includes/config.php';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stasis - 404</title>
    <link rel="stylesheet" href="/assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .error-box {


            padding: 40px;
            text-align: center;
            max-width: 500px;
        }
        
        .error-image {
            width: 200px;
            height: 200px;
            margin: 0 auto 20px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .error-image img {
            max-width: 100%;
            max-height: 100%;
        }
        
        .error-code {
            font-size: 80px;
            color: #ffffff;
            font-weight: bold;
            line-height: 1;
            margin-bottom: 10px;
        }
        
        .error-text {
            color: #ffffff;
            margin-bottom: 25px;
            font-size: 16px;
        }
        
        .error-links {
            display: flex;
            gap: 15px;
            justify-content: center;
        }
        
        .error-links a {
            padding: 8px 20px;
            background: #1a1a1a;
            border: 1px solid #333;
            color: #ccc;
            text-decoration: none;
            font-size: 14px;
        }
        
        .error-links a:hover {
            border-color: #ffffff;
            color: #ffffff;
        }
        
        .error-links a.home {
            background: #ffffff;
            border-color: #ffffff;
            color: #000;
        }
    </style>
</head>
<body>
    <?php include 'includes/nav.php'; ?>

    <div class="container">
        <div class="error-box">
            <div class="error-image">
                <img src="/assets/images/404.png" alt="404" onerror="this.style.display='none'; this.parentNode.innerHTML='<i class=\'fas fa-hourglass\' style=\'font-size:80px; color:#333;\'></i>';">
            </div>
            <div class="error-code">404</div>
            <div class="error-text">Page not found</div>
            <div class="error-links">
                <a href="/index.php"><i class="fas fa-home"></i> Home</a>
                <a href="javascript:history.back()"><i class="fas fa-arrow-left"></i> Back</a>
            </div>
        </div>
    </div>

    <div class="footer">
        © 2026 Stasis
    </div>
</body>
</html>