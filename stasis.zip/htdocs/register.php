<?php
require_once 'includes/config.php';


if (isLoggedIn()) {
    header('Location: home.php');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    

    if (strlen($username) < 3) {
        $error = 'Username must be at least 3 characters';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email address';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters';
    } else {

        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $email]);
        
        if ($stmt->fetch()) {
            $error = 'Username or email already taken';
        } else {
     
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
            
            if ($stmt->execute([$username, $email, $hash])) {
                $success = 'Account created! Redirecting to login...';
                header('refresh:2; url=login.php');
            } else {
                $error = 'Something went wrong. Try again.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stasis - Sign Up</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="nav">
        <div class="nav-left">
            <img src="assets/images/logo2.png" alt="STASIS" class="logo">
            <div class="nav-links">
                  <a href="/home.php">Home</a> 
                <a href="/games.php">Games</a>
                <a href="/catalog/catalog.php">Catalog</a>
                <a href="/create.php">Create</a>
            </div>
        </div>
        <div class="nav-right">
            <a href="https://discord.gg/d2sHx4wmcn">Discord</a>
        </div>
    </div>

    <div class="container">
        <div class="form-container">
            <img src="assets/images/logo2.png" alt="STASIS" class="form-logo">
            <div class="tagline">Create your account</div>
            
            <?php if ($error): ?>
                <div class="error-msg"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="success-msg"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="input-group">
                    <input type="text" name="username" placeholder="Username" required value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>">
                </div>
                <div class="input-group">
                    <input type="email" name="email" placeholder="Email" required value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                </div>
                <div class="input-group">
                    <input type="password" name="password" placeholder="Password" required>
                </div>
                
                <button type="submit" class="form-btn">SIGN UP</button>
            </form>
            
            <div class="form-footer">
                <a href="login.php">Already have an account? Sign in</a>
            </div>
        </div>
    </div>

    <div class="footer">
        © 2026 Stasis
    </div>
</body>
</html>