<?php
require_once 'includes/config.php';

if (isLoggedIn()) {
    header('Location: home.php');
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stasis</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="nav">
        <div class="nav-left">
            <img src="assets/images/logo2.png" alt="STASIS" class="logo">
            <div class="nav-links">
                   <a href="/home.php">Home</a> 
                <a href="/games.php">Games</a>
                <a href="/catalog/catalog.php">Catalog</a>
                <a href="/create.php">Create</a>
            </div>
        </div>
        <div class="nav-right">
            <a href="https://discord.gg/d2sHx4wmcn">Discord</a>
        </div>
    </div>

    <div class="container">
        <img src="assets/images/logo2.png" alt="STASIS" class="main-logo">
        <div class="tagline">Experience 2014 for free</div>
        <div class="buttons">
            <button class="btn btn-signup" onclick="window.location.href='register.php'">SIGN UP</button>
            <button class="btn btn-signin" onclick="window.location.href='login.php'">SIGN IN</button>
        </div>
    </div>

    <div class="footer">
        © 2026 Stasis
    </div>
</body>
</html>