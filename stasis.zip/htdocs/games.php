<?php
require_once 'includes/config.php';


$sort = isset($_GET['sort']) ? $_GET['sort'] : 'plays';
$search = isset($_GET['search']) ? $_GET['search'] : '';


$sql = "SELECT * FROM games WHERE 1=1";
$params = [];

if (!empty($search)) {
    $sql .= " AND (name LIKE ? OR description LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}


if ($sort == 'plays') {
    $sql .= " ORDER BY plays DESC";
} elseif ($sort == 'rating') {
    $sql .= " ORDER BY rating DESC";
} elseif ($sort == 'new') {
    $sql .= " ORDER BY created_at DESC";
} else {
    $sql .= " ORDER BY plays DESC";
}

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$games = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stasis - Games</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .games-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 20px;
        }
        
        .games-title {
            color: #888;
            font-size: 28px;
        }
        
        .games-search {
            display: flex;
            gap: 10px;
            flex: 1;
            max-width: 400px;
        }
        
        .games-search input {
            flex: 1;
            padding: 10px;
            background: #1a1a1a;
            border: 1px solid #333;
            color: #fff;
        }
        
        .games-search button {
            padding: 10px 20px;
            background: #1a1a1a;
            border: 1px solid #333;
            color: #fff;
            cursor: pointer;
        }
        
        .games-sort {
            display: flex;
            gap: 10px;
        }
        
        .sort-btn {
            padding: 8px 15px;
            background: #1a1a1a;
            border: 1px solid #333;
            color: #ccc;
            text-decoration: none;
            font-size: 14px;
        }
        
        .sort-btn.active {
            border-color: #fcd94c;
            color: #fcd94c;
        }
        
        .games-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-top: 20px;
        }
        
        .game-card {
            background: #1a1a1a;
            border: 1px solid #333;
            padding: 15px;
            text-decoration: none;
            color: inherit;
            transition: 0.2s;
        }
        
        .game-card:hover {
            border-color: #fcd94c;
            transform: translateY(-2px);
        }
        
        .game-thumbnail {
            width: 100%;
            aspect-ratio: 1;
            background: #222;
            border: 1px solid #333;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #444;
            font-size: 40px;
        }
        
        .game-title {
            color: #fff;
            font-size: 16px;
            margin-bottom: 5px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .game-creator {
            color: #888;
            font-size: 12px;
            margin-bottom: 8px;
        }
        
        .game-stats {
            display: flex;
            justify-content: space-between;
            color: #888;
            font-size: 13px;
            margin-top: 8px;
        }
        
        .game-rating {
            color: #fcd94c;
        }
        
        .game-plays {
            color: #666;
        }
        
        .no-games {
            grid-column: 1/-1;
            text-align: center;
            padding: 50px;
            color: #666;
        }
    </style>
</head>
<body>
    <?php include 'includes/nav.php'; ?>

    <div class="container">
        <div class="games-header">
            <h1 class="games-title">Games</h1>
            
            <form method="GET" class="games-search">
                <input type="text" name="search" placeholder="Search games..." value="<?php echo htmlspecialchars($search); ?>">
                <button type="submit"><i class="fas fa-search"></i></button>
            </form>
            
            <div class="games-sort">
                <a href="?sort=plays<?php echo $search ? '&search='.$search : ''; ?>" class="sort-btn <?php echo $sort == 'plays' ? 'active' : ''; ?>">Most Played</a>
                <a href="?sort=rating<?php echo $search ? '&search='.$search : ''; ?>" class="sort-btn <?php echo $sort == 'rating' ? 'active' : ''; ?>">Top Rated</a>
                <a href="?sort=new<?php echo $search ? '&search='.$search : ''; ?>" class="sort-btn <?php echo $sort == 'new' ? 'active' : ''; ?>">Newest</a>
            </div>
        </div>
        
        <div class="games-grid">
            <?php if (empty($games)): ?>
                <div class="no-games">No games found.</div>
            <?php else: ?>
                <?php foreach ($games as $game): ?>
                    <a href="game.php?id=<?php echo $game['id']; ?>" class="game-card">
                        <div class="game-thumbnail">
                            <?php if ($game['thumbnail_url']): ?>
                                <img src="<?php echo $game['thumbnail_url']; ?>" style="width:100%; height:100%; object-fit:cover;">
                            <?php else: ?>
                                <i class="fas fa-gamepad"></i>
                            <?php endif; ?>
                        </div>
                        <div class="game-title"><?php echo htmlspecialchars($game['name']); ?></div>
                        <div class="game-creator">by <?php echo htmlspecialchars($game['creator_name']); ?></div>
                        <div class="game-stats">
                            <span class="game-rating"><i class="fas fa-star"></i> <?php echo $game['rating']; ?></span>
                            <span class="game-plays"><i class="fas fa-users"></i> <?php echo number_format($game['plays']); ?></span>
                        </div>
                    </a>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>
</body>
</html>