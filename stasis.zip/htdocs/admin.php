<?php
require_once 'includes/config.php';
requireLogin();

$user = getCurrentUser();
if ($user['username'] !== '123') {
    header('Location: home.php');
    exit;
}

if (isset($_GET['action'])) {
    if ($_GET['action'] == 'delete_user' && isset($_GET['id'])) {
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ? AND username != '123'");
        $stmt->execute([$_GET['id']]);
        header('Location: admin.php');
        exit;
    }
    
    if ($_GET['action'] == 'delete_item' && isset($_GET['id'])) {
        $stmt = $pdo->prepare("DELETE FROM catalog_items WHERE id = ?");
        $stmt->execute([$_GET['id']]);
        header('Location: admin.php');
        exit;
    }
    
    if ($_GET['action'] == 'add_currency' && isset($_GET['id']) && isset($_GET['amount'])) {
        $stmt = $pdo->prepare("UPDATE users SET currency = currency + ? WHERE id = ?");
        $stmt->execute([$_GET['amount'], $_GET['id']]);
        header('Location: admin.php');
        exit;
    }
}

$totalUsers = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$totalItems = $pdo->query("SELECT COUNT(*) FROM catalog_items")->fetchColumn();
$totalSales = $pdo->query("SELECT COUNT(*) FROM inventory")->fetchColumn();

$users = $pdo->query("SELECT id, username, email, currency, created_at FROM users ORDER BY id DESC LIMIT 20")->fetchAll();

$items = $pdo->query("SELECT * FROM catalog_items ORDER BY id DESC LIMIT 20")->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Stasis</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .admin-container {
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .admin-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }
        
        .admin-title {
            color: #fcd94c;
            font-size: 28px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-bottom: 40px;
        }
        
        .stat-card {
            background: #1a1a1a;
            border: 1px solid #333;
            padding: 25px;
            text-align: center;
        }
        
        .stat-number {
            font-size: 36px;
            color: #fcd94c;
            font-weight: bold;
        }
        
        .stat-label {
            color: #888;
            margin-top: 5px;
            font-size: 14px;
        }
        
        .section-title {
            color: #fff;
            font-size: 20px;
            margin: 30px 0 15px;
        }
        
        .admin-table {
            width: 100%;
            background: #1a1a1a;
            border: 1px solid #333;
            border-collapse: collapse;
        }
        
        .admin-table th {
            background: #0f1217;
            color: #888;
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #333;
            font-weight: normal;
        }
        
        .admin-table td {
            padding: 12px;
            color: #ccc;
            border-bottom: 1px solid #222;
        }
        
        .admin-table tr:hover {
            background: #222;
        }
        
        .admin-btn {
            padding: 5px 10px;
            background: #0f1217;
            border: 1px solid #333;
            color: #ccc;
            text-decoration: none;
            font-size: 12px;
            margin-right: 5px;
            display: inline-block;
        }
        
        .admin-btn:hover {
            border-color: #fcd94c;
            color: #fcd94c;
        }
        
        .admin-btn.delete:hover {
            border-color: #ff4444;
            color: #ff4444;
        }
        
        .currency-input {
            width: 60px;
            padding: 3px;
            background: #0f1217;
            border: 1px solid #333;
            color: #fff;
            margin-right: 5px;
        }
        
        .add-form {
            display: inline-block;
        }
    </style>
</head>
<body>
    <?php include 'includes/nav.php'; ?>

    <div class="container">
        <div class="admin-container">
            <div class="admin-header">
                <h1 class="admin-title"><i class="fas fa-crown"></i> Admin Panel</h1>
                <a href="home.php" class="admin-btn">Back to Site</a>
            </div>
            
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-number"><?php echo $totalUsers; ?></div>
                    <div class="stat-label">Total Users</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?php echo $totalItems; ?></div>
                    <div class="stat-label">Catalog Items</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?php echo $totalSales; ?></div>
                    <div class="stat-label">Items Sold</div>
                </div>
            </div>
            
            <h2 class="section-title"><i class="fas fa-users"></i> Recent Users</h2>
            <table class="admin-table">
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Currency</th>
                    <th>Joined</th>
                    <th>Actions</th>
                </tr>
                <?php foreach ($users as $u): ?>
                <tr>
                    <td><?php echo $u['id']; ?></td>
                    <td><?php echo htmlspecialchars($u['username']); ?></td>
                    <td><?php echo htmlspecialchars($u['email']); ?></td>
                    <td><?php echo $u['currency']; ?></td>
                    <td><?php echo date('M j, Y', strtotime($u['created_at'])); ?></td>
                    <td>
                        <form class="add-form" method="GET" style="display: inline;">
                            <input type="hidden" name="id" value="<?php echo $u['id']; ?>">
                            <input type="hidden" name="action" value="add_currency">
                            <input type="number" name="amount" placeholder="+" class="currency-input" min="1">
                            <button type="submit" class="admin-btn"><i class="fas fa-plus"></i></button>
                        </form>
                        <?php if ($u['username'] !== 'admin'): ?>
                            <a href="?action=delete_user&id=<?php echo $u['id']; ?>" class="admin-btn delete" onclick="return confirm('Delete user?')"><i class="fas fa-trash"></i></a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
            
            <h2 class="section-title"><i class="fas fa-box"></i> Recent Items</h2>
            <table class="admin-table">
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Type</th>
                    <th>Price</th>
                    <th>Actions</th>
                </tr>
                <?php foreach ($items as $item): ?>
                <tr>
                    <td><?php echo $item['id']; ?></td>
                    <td><?php echo htmlspecialchars($item['name']); ?></td>
                    <td><?php echo $item['type']; ?></td>
                    <td><?php echo $item['price']; ?></td>
                    <td>
                        <a href="/catalog/item.php?id=<?php echo $item['id']; ?>" class="admin-btn"><i class="fas fa-eye"></i></a>
                        <a href="?action=delete_item&id=<?php echo $item['id']; ?>" class="admin-btn delete" onclick="return confirm('Delete item?')"><i class="fas fa-trash"></i></a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>
</body>
</html>